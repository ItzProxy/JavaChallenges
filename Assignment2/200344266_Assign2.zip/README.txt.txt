All files can be seen on Github (https://github.com/ItzProxy/JavaChallenges/tree/master/Assignment2)

a2p1
This include both part 1 and part 2 of assignment
Account.java
Test.java

a2p3
CargoShip.java
CruiseShip.java
Ship.java
Test.java

a2p4
Split.java

a2p5
MyString2.java - this include a main function that test all the functions found in MyString2.java