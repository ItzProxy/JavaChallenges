package q3;

public interface Drawable{
    public void draw();
}